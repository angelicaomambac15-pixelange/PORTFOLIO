<div id="bottom1">
  <div class="wrapper">
    <div class="btm1_con">
      <section class="btm1_box1">
        <h2>Heading <span>Sub</span></h2>
        <p>TextHere</p>
        <a href="#">LinkThis</a>
      </section>

      <section class="btm1_box2">
        <h2>Heading <span>Sub</span></h2>
        <p>TextHere</p>
        <a href="#">LinkThis</a>
      </section>

      <section class="btm1_box3">
        <h2>Heading <span>Sub</span></h2>
        <p>TextHere</p>
        <a href="#">LinkThis</a>
      </section>
    </div>
  </div>
</div>

<div id="bottom2">
  <div class="wrapper">
    <div class="btm2_con">
      <h2>Heading<span>Sub</span></h2>
  		<p>TextHere</p>
  		<a href="#">LinkThis</a>
    </div>
  </div>
</div>
