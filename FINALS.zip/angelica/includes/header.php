<header>
  <div class="wrapper">
    <div class="logo">
      <a href="<?php //echo get_home_url(); ?>"><img src="images/main_logo.png" alt="<?php //echo get_bloginfo('name');?>"/></a>
    </div>

    <div class="header_info">
      <h3>Contact <span>number</span></h3>
    </div>

    <div class="header_right">
      <!-- <ul>
				<li><a href="http://facebook.com" target="_blank"><img src="images/icon_fb.png" alt="Facebook"></a></li>
				<li><a href="http://twitter.com" target="_blank"><img src="images/icon_twitter.png" alt="Twitter"></a></li>
				<li><a href="https://linkedin.com/" target="_blank"><img src="images/icon_link.png" alt="LinkedIn"></a></li>
				<li><a href="https://youtube.com/" target="_blank"><img src="images/icon_ytube.png" alt="YouTube"></a></li>
				<li><a href="https://pinterest.com/" target="_blank"><img src="images/icon_pin.png" alt="Pinterest"></a></li>
				<li><a href="https://plus.google.com/" target="_blank"><img src="images/icon_gplus.png" alt="Google Plus"></a></li>
        <li><a href="http://instagram.com" target="_blank"><img src="images/icon_insta.png" alt="Instagram"></a></li>
			</ul> -->
    </div>
    <div class="clearfix"></div>
  </div>
</header>
