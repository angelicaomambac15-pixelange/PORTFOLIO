<div id="middle">
  <div class="wrapper">
    <div class="middle_con">
      <section class="mid_box1">
        <h2>Heading <span>Sub</span></h2>
        <p>TextHere</p>
        <a href="#">LinkThis</a>
      </section>
      <section class="mid_box2">
        <h2>Heading <span>Sub</span></h2>
        <p>TextHere</p>
        <a href="#">LinkThis</a>
      </section>
      <section class="mid_box3">
        <h2>Heading <span>Sub</span></h2>
        <p>TextHere</p>
        <a href="#">LinkThis</a>
      </section>
    </div>
  </div>
</div>
