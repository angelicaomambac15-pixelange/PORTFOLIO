<div id="banner">
  <div class="wrapper">
    <div class="slider">
      <!-- <div class="box_skitter box_skitter_large">
        <ul>
          <li><img src="images/slider/1.jpg" alt="" class="random"/></li>
          <li><img src="images/slider/2.jpg" alt="" class="random"/></li>
          <li><img src="images/slider/3.jpg" alt="" class="random"/></li>
        </ul>
      </div> -->
      <ul class="rslides">
        <li><img src="images/slider/1.jpg" alt=""/></li>
        <li><img src="images/slider/2.jpg" alt=""/></li>
        <li><img src="images/slider/3.jpg" alt=""/></li>
      </ul>
    </div>

    <img src="images/slider/1.jpg" alt="" class="mobi_ban">

    <div class="bnr_info">
      <div class="slogan">
        <h2>SloganHere</h2>
      </div>
    </div>
  </div>
</div>
