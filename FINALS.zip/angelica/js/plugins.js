$(document).ready(function(){

	// Global Variables

		var toggle_primary_button = $('.nav_toggle_button'),
				toggle_primary_icon = $('.nav_toggle_button i'),
				toggle_secondary_button = $('.page_nav li span'),
				primary_menu = $('.page_nav'),
				secondary_menu = $('.page_nav ul ul'),
				webHeight = $(document).height(),
				window_width = $(window).width();

	// Company name and phone number on content area
	$("main * :not('h1')").not('.woocommerce *').each(function() {
		var regex1 = /(?![^<]+>)((\+\d{1,2}[\s.-])?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{6})/g;
		var regex2 = /(?![^<]+>)((\+\d{1,2}[\s.-])?\(?\d{3}\)?[\s.-]?\d{4}[\s.-]?\d{4})/g;
		var regex = /(?![^<]+>)((\+\d{1,2}[\s.-])?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4})/g;
				$(this).html(
						$(this).html()
						.replace(/CompanyName/gi, "<mark class='comp'>$&</mark>")
						.replace(regex1, "<mark class='main_phone'>$&</mark>").replace(regex2, "<mark class='main_phone'>$&</mark>").replace(regex, "<mark class='main_phone'>$&</mark>"));
		});

		$("main a[href]").each(function() {
		   var newHref = $(this).attr('href').replace("<mark class='comp'>", "").replace("</mark>", "");
			 $(this).attr('href', newHref);
		});

		// Forms on content area
		var form = $('main').find('#myframe');
			if(form.length > 0) {
			document.getElementById('myframe').onload = function(){
			  calcHeight();
			};
		}

	// Add class to tab having drop down
	$( ".page_nav li:has(ul)").find('span i').addClass("fa-caret-down");


	//Multi-line Tab
	toggle_secondary_button.click(function(){
		$(this).parent('li').siblings('li').children('ul').slideUp(400, function() {
			$(this).removeAttr('style');
		});

		$(this).parent('li').siblings('li').find('.fa').removeClass("fa-caret-up").addClass("fa-caret-down");

		$(this).parent('li').children('ul').slideToggle();
		$(this).children().toggleClass("fa-caret-up").toggleClass("fa-caret-down");
	});

	// Basic functionality for nav_toggle

	var hamburger = $(".hamburger");
    // hamburger.each(function(){
        // $(this).click(function(){
         // $(this).toggleClass("is-active");
        // });
      // });

	  hamburger.click(function(){
		primary_menu.addClass('toggle_right_style');
		$('.toggle_right_nav').addClass('toggle_right_cont');
		$(".nav_toggle_button").toggleClass('active');
		$(".hamburger").toggleClass("is-active");
		$('body').addClass('active');
	});


	$('.toggle_nav_close, .menu_slide_right .hamburger').click(function(){
		primary_menu.removeClass('toggle_right_style');
		secondary_menu.removeAttr('style');
		toggle_secondary_button.children().removeClass("fa-caret-up").addClass("fa-caret-down");
		$('.toggle_right_nav').removeClass('toggle_right_cont');
		$(".nav_toggle_button").removeClass('active');
		$(".hamburger").removeClass("is-active");
		$('body').removeClass('active');
	});

	// Swap Elements
	function swap_this(){
		if (window_width > 1000){
				$("#nav_area").insertAfter(".header_con");
		} else if (window_width <= 800){
			$('.main_logo').insertAfter('.logo_wrap');
			$('#nav_area').insertBefore('header');
			// $('.toggle_holder').insertBefore('.main_logo');
		} else {
			$('.main_logo').insertAfter('.logo_wrap');
			$('#nav_area').insertBefore('header');
		}
	}

	swap_this();

	// Reset all configs when width > 800
	$(window).resize(function(){
		window_width = $(this).width();

		swap_this();

		if(window_width > 800) {
			$(".nav_toggle_button").removeClass('active');
			$(".hamburger").removeClass("is-active");
			primary_menu.removeClass('toggle_right_style');
			$('.toggle_right_nav').removeClass('toggle_right_cont');
			$('body').removeClass('active');
		}
		else{
			secondary_menu.removeAttr('style');
			toggle_secondary_button.children().removeClass("fa-caret-up").addClass("fa-caret-down");
		}


	});

	$('.faq h6').click(function(){
		$(this).next().slideToggle()
	   .siblings('.faq div').slideUp();
	   //toggle sign
		$(this).toggleClass('sign')
		.siblings('.faq h6').removeClass();
	  });

	  $('.resume_pop').click(function(){
		$('#modal_parent').css("display","block").animate();
	  });

	  $('.modal_close').click(function(){
		$('#modal_parent').css("display","none");
	  });

	  
	$("#close-btn").click(function(){
		// remove active class from all images
	   $(".small-image").removeClass('active');
	   $("#show_image_popup").slideUp();
	 });

	 $('.page_nav ul li').click(function(){
		$(this).siblings('.page_nav ul li').addClass('current_page');
		$(this).addClass('current_page').siblings('.page_nav ul li').removeClass();
 
	 });

	//  $(".small-image").click(function(){
	// 	 // remove active class from all images
	// 	$(".small-image").removeClass('active');
	// 	$(".content_here").removeClass('active');
	//    // add active class
	// 	$(this).addClass('active');
 
	//    var image_path = $(this).attr('src'); 
	//    var content_path = $(this).attr('p'); 
 
	//    // now st this path to our popup image src
	//    $("#show_image_popup").css("display", "block");
	//    $("#large-image").attr('src',image_path);
	//    $("#content-insert").attr('p',content_path);
 
	//  });


 
		$(".owl-carousel").owlCarousel({
			loop: true,
			items: 3,
			autoplay: true,
			responsive:{
				1000:{
					items: 3
				},
				800: {
					items: 2
				},
				300: {
					items: 1
				}
				

			}
		

		});

		
		var fixmeTop = $('.page_nav').offset().top;       // get initial position of the element

		$(window).scroll(function() {                  // assign scroll event listener
		
			var currentScroll = $(window).scrollTop(); // get current position
		
			if (currentScroll >= fixmeTop && window_width <= 1000) {           // apply position: fixed if you
				$('.page_nav').css({                      // scroll to that element or below it
					position: 'fixed',
					top: '0',
					left: '0',
					padding: '75px 15px 20px'
					
					 
				});
			} else {                                   // apply position: static
				$('.page_nav').css({                      // if you scroll above it
					position: 'static',
					margin: '0 auto'
				});
			}
		
		});



	$('.rslides').responsiveSlides();
	// $(".box_skitter_large").skitter();

	$('.back_top').click(function () { // back to top
		$("html, body").animate({
			scrollTop: 0
		}, 900);
		return false;
	});

	$(window).scroll(function(){  // fade in fade out button
	var windowScroll = $(this).scrollTop();

		if (windowScroll > (webHeight * 0.5) && window_width <= 600 ) {
			$(".back_top").fadeIn();
		} else{
			$(".back_top").fadeOut()
		};

		// For (AddThis) Plugins
		if($('body #at-share-dock').hasClass('at-share-dock')) {
			$('.back_top').addClass('withAddThis_plugins');
			$('.footer_btm').addClass('withAddThis_ftr_btm');
		} else {
			$('.back_top').removeClass('withAddThis_plugins');
			$('.footer_btm').removeClass('withAddThis_ftr_btm');
		}
		// End (AddThis) Plugins
	});

});
